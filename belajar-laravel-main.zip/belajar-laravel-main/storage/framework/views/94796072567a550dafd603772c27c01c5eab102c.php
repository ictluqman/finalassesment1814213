<footer class="text-muted">
    <div class="container">
        <p>Laravel Project &copy; Pixel Developer</p>
    </div>
</footer><?php /**PATH C:\Users\Luqman Azmi\belajar-laravel-main\resources\views/includes/public/footer.blade.php ENDPATH**/ ?>