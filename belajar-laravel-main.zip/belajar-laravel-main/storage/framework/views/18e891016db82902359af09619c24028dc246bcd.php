<?php $__env->startSection('content'); ?>
<div class="container">

    <?php if(session('message')): ?>
        <div class="alert alert-success"><?php echo session('message'); ?></div>
    <?php endif; ?>

    <div class="card">
        <div class="card-body">
            <div class="d-flex justify-content-between align-items-center">
                <h5 class="card-title">Your Posts</h5>
                <a href="<?php echo e(route('post.create')); ?>" class="btn btn-primary">Create a new post</a>
            </div>
            <?php $__empty_1 = true; $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="d-flex justify-content-between align-items-center my-2">
                <div class="d-flex align-items-center">
                    <img width="125px" height="75px" src="<?php echo e(asset('storage/' . $post->image )); ?>" alt="default" style="object-fit: cover;">
                    <div class="ml-3">
                        <p><?php echo e($post->title); ?></p>
                        <p class="text-muted"><?php echo e($post->created_at->format('Y-M-d')); ?> &middot; <?php echo e($post->created_at->diffForHumans()); ?></p>
                    </div>
                </div>
                <div>
                    <a href="<?php echo e(route('post.edit', $post->slug)); ?>" class="btn btn-success">
                        <svg xmlns="http://www.w3.org/2000/svg" width="22px" height="22px" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15.232 5.232l3.536 3.536m-2.036-5.036a2.5 2.5 0 113.536 3.536L6.5 21.036H3v-3.572L16.732 3.732z" />
                        </svg>
                    </a>
                    <form action="<?php echo e(route('post.destroy', $post->slug)); ?>" method="POST" class="d-inline">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="btn btn-danger" onclick="return confirm('Apakah anda yakin untuk menghapus postingan ini?')">
                            <svg xmlns="http://www.w3.org/2000/svg" width="22px" height="22px" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                            </svg>
                        </button>
                    </form>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <div class="alert alert-danger mt-3 text-center" role="alert">
                You don't have any posts
            </div>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Luqman Azmi\belajar-laravel-main\resources\views/private/post/index.blade.php ENDPATH**/ ?>