<?php $__env->startSection('custom-style'); ?>
    <style>
        .move-vertical-animation{
            transition: 0.2s;
        }

        .move-vertical-animation:hover{
            transform: translateY(-10px);
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<main role="main">

    <div class="album py-5 bg-light">
        <div class="container">

            <div class="row">
                <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-4">
                    <div class="card mb-4 shadow-sm move-vertical-animation">
                        <a href="<?php echo e(route('post.show', $post->slug)); ?>">
                            <img width="348px" height="225px" src="<?php echo e(asset('storage/' . $post->image)); ?>" style="object-fit: cover;">
                        </a>

                        <div class="card-body">
                            <p class="card-text"><?php echo e($post->description); ?></p>
                            <div class="d-flex justify-content-between align-items-center">
                                <small class="text-muted"><?php echo e($post->user->name); ?></small>
                                <small class="text-muted"><?php echo e($post->created_at->diffForHumans()); ?></small>
                            </div>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>

</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Luqman Azmi\belajar-laravel-main\resources\views/public/post/index.blade.php ENDPATH**/ ?>