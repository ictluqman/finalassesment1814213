<footer class="text-muted">
    <div class="container">
        <p>Laravel Project &copy; Pixel Developer</p>
    </div>
</footer>